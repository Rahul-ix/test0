public class 3SumClosest {
    public static void main(String[] args) {
        System.out.println("Solution for 3Sum Closest");
    }
}
