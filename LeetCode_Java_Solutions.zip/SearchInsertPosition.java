public class SearchInsertPosition {
    public static void main(String[] args) {
        System.out.println("Solution for Search Insert Position");
    }
}
