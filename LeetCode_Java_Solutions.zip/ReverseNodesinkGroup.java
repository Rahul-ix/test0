public class ReverseNodesinkGroup {
    public static void main(String[] args) {
        System.out.println("Solution for Reverse Nodes in k-Group");
    }
}
