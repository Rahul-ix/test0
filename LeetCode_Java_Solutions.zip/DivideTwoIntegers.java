public class DivideTwoIntegers {
    public static void main(String[] args) {
        System.out.println("Solution for Divide Two Integers");
    }
}
