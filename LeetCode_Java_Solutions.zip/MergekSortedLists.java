public class MergekSortedLists {
    public static void main(String[] args) {
        System.out.println("Solution for Merge k Sorted Lists");
    }
}
