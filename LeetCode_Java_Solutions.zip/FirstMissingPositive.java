public class FirstMissingPositive {
    public static void main(String[] args) {
        System.out.println("Solution for First Missing Positive");
    }
}
