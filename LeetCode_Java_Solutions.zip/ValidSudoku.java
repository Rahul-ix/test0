public class ValidSudoku {
    public static void main(String[] args) {
        System.out.println("Solution for Valid Sudoku");
    }
}
