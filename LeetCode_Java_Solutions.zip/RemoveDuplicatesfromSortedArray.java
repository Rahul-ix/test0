public class RemoveDuplicatesfromSortedArray {
    public static void main(String[] args) {
        System.out.println("Solution for Remove Duplicates from Sorted Array");
    }
}
