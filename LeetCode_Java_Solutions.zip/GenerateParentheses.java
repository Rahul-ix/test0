public class GenerateParentheses {
    public static void main(String[] args) {
        System.out.println("Solution for Generate Parentheses");
    }
}
