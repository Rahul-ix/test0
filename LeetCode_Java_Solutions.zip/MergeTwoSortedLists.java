public class MergeTwoSortedLists {
    public static void main(String[] args) {
        System.out.println("Solution for Merge Two Sorted Lists");
    }
}
