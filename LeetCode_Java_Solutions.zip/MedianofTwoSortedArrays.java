public class MedianofTwoSortedArrays {
    public static void main(String[] args) {
        System.out.println("Solution for Median of Two Sorted Arrays");
    }
}
