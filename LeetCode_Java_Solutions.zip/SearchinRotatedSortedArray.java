public class SearchinRotatedSortedArray {
    public static void main(String[] args) {
        System.out.println("Solution for Search in Rotated Sorted Array");
    }
}
