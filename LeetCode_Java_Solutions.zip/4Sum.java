public class 4Sum {
    public static void main(String[] args) {
        System.out.println("Solution for 4Sum");
    }
}
