public class FindFirstandLastPositionofElementinSortedArray {
    public static void main(String[] args) {
        System.out.println("Solution for Find First and Last Position of Element in Sorted Array");
    }
}
