public class AddTwoNumbers {
    public static void main(String[] args) {
        System.out.println("Solution for Add Two Numbers");
    }
}
