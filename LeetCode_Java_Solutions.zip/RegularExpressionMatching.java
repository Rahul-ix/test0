public class RegularExpressionMatching {
    public static void main(String[] args) {
        System.out.println("Solution for Regular Expression Matching");
    }
}
