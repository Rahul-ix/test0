public class MultiplyStrings {
    public static void main(String[] args) {
        System.out.println("Solution for Multiply Strings");
    }
}
