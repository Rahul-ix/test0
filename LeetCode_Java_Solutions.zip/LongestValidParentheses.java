public class LongestValidParentheses {
    public static void main(String[] args) {
        System.out.println("Solution for Longest Valid Parentheses");
    }
}
