public class StringtoIntegeratoi {
    public static void main(String[] args) {
        System.out.println("Solution for String to Integer (atoi)");
    }
}
