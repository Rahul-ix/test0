public class SubstringwithConcatenationofAllWords {
    public static void main(String[] args) {
        System.out.println("Solution for Substring with Concatenation of All Words");
    }
}
