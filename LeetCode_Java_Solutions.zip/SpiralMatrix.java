public class SpiralMatrix {
    public static void main(String[] args) {
        System.out.println("Solution for Spiral Matrix");
    }
}
