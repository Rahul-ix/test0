public class 3Sum {
    public static void main(String[] args) {
        System.out.println("Solution for 3Sum");
    }
}
