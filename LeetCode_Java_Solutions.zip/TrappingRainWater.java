public class TrappingRainWater {
    public static void main(String[] args) {
        System.out.println("Solution for Trapping Rain Water");
    }
}
