public class SudokuSolver {
    public static void main(String[] args) {
        System.out.println("Solution for Sudoku Solver");
    }
}
