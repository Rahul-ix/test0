public class ZigzagConversion {
    public static void main(String[] args) {
        System.out.println("Solution for Zigzag Conversion");
    }
}
