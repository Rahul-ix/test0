public class LetterCombinationsofaPhoneNumber {
    public static void main(String[] args) {
        System.out.println("Solution for Letter Combinations of a Phone Number");
    }
}
