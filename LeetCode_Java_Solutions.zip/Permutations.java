public class Permutations {
    public static void main(String[] args) {
        System.out.println("Solution for Permutations");
    }
}
