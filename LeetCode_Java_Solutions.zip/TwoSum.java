public class TwoSum {
    public static void main(String[] args) {
        System.out.println("Solution for Two Sum");
    }
}
