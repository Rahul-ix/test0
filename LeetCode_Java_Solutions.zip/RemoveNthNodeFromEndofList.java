public class RemoveNthNodeFromEndofList {
    public static void main(String[] args) {
        System.out.println("Solution for Remove Nth Node From End of List");
    }
}
