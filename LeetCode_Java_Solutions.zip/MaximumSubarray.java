public class MaximumSubarray {
    public static void main(String[] args) {
        System.out.println("Solution for Maximum Subarray");
    }
}
