public class JumpGameII {
    public static void main(String[] args) {
        System.out.println("Solution for Jump Game II");
    }
}
