public class Powx,n {
    public static void main(String[] args) {
        System.out.println("Solution for Pow(x, n)");
    }
}
