public class RemoveElement {
    public static void main(String[] args) {
        System.out.println("Solution for Remove Element");
    }
}
