public class ImplementstrStr {
    public static void main(String[] args) {
        System.out.println("Solution for Implement strStr()");
    }
}
