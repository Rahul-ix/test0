public class SwapNodesinPairs {
    public static void main(String[] args) {
        System.out.println("Solution for Swap Nodes in Pairs");
    }
}
